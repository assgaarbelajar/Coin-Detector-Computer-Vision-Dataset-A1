# Coin Detector > 2024-06-10 1:22pm
https://universe.roboflow.com/a1-kpq8b/coin-detector-a0uyb

Provided by a Roboflow user
License: CC BY 4.0

